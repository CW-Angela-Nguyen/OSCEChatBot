# PharmBot OSCE Chatbot

A clean React-based web app with ChatGPT integration for intern pharmacist OSCE simulation.
