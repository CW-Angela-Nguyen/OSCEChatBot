
export const monthlyCases = {
  May: [
    { id: "2.3.1", title: "Migraine", topic: "Headache", casePrompt: "Hi, I’ve had a headache for two days..." },
    { id: "2.4.2", title: "Tonsillitis", topic: "Sore Throat", casePrompt: "My throat is really sore and it hurts to swallow..." }
  ]
};
